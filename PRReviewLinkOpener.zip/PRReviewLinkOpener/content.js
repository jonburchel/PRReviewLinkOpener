if (!document.location.href.startsWith("https://github.com/MicrosoftDocs/") 
    || !document.location.href.includes("/pull/"))
{
    alert("This extension works with Git Pull Requests to Microsoft Docs.\rPlease try again from a PR under https://github.com/MicrosoftDocs.");
}
else
{
    var h3s = Array.from(document.querySelectorAll('h3'));
    var i = 0;
    for (i = h3s.length - 1; i > 0; i--)
    {
        if (h3s[i].innerText.includes('Validation status:'))
            break;
    }
    if (i > 0)
    {
        ValidationTable = h3s[i].nextElementSibling;
        var rows = ValidationTable.rows;
        if (confirm("Open " + (rows.length - 1) + " preview page" + (rows.length > 2 ? "s" : "") + " for this PR?"))
        {
            for (var j = 1; j < rows.length; j++)
                window.open(rows[j].children[2].children[0], "_blank");
        }
    }
    else
    {
        alert("There are no preview URLs available yet for this PR.");
    }
}